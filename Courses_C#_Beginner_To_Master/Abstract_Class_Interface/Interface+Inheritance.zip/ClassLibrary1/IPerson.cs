﻿//parent interface
public interface IPerson
{
    System.DateTime DateOfBirth { get; set; }
    int GetAge();
}

